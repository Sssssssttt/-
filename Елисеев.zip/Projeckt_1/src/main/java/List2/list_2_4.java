package List2;

public class list_2_4 {
    public  static  void main(String[] args) {
        int count;
        for (count = 0; count < 5; count = count + 1)
            System.out.println("Переменная цикла равна" + 1);
        System.out.println("Цикл окончен");

    } // main(String[]) method
} // ForStatementDemo class
