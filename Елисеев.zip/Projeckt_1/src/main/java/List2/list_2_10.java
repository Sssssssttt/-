package List2;

public class list_2_10 {
    public static  void main(String[] args) {
        double radius = 4;
        double height = 5;
        double volume = 3.1416 * radius * radius * height;
        System.out.println("Объем цилиндра равен " + volume);
    } // main(String[]) method
} // CylinderVolume class
