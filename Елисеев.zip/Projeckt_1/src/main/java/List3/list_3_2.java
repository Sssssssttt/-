package List3;


    class list_3_2 {
        int passengers; // количество пассажиров
        int wheels; // количество колес
        int maxspeed; // максимальная скорость
        int burnup; // расход топлива
    } // Vehicle class

    class MoreVehicleDemo {
        public static void main(String[] args) {

            list_3_2 car1 = new list_3_2();
            car1.passengers = 2;
            car1.wheels = 6;
            car1.maxspeed = 130;
            car1.burnup = 30;
// другой экземпляр класса Vehicle: объект bus1
            list_3_2 bus1 = new list_3_2();
            bus1.passengers = 45;
            bus1.wheels = 4;
            bus1.burnup = 45;
// расчет пути пройденного за 1.25 часа
            double interval = 1.25;
            double distanceCar = car1.maxspeed * interval;
            double distanceBus = bus1.maxspeed * interval;
            System.out.println("car1 может проехать за 1 час 15 мие. расстояние в ");
            System.out.println(distanceCar + " км c" + car1.passengers);
            System.out.println(" пассажирами");
            System.out.println("bus1 может проехать за 1 час 15 мин. расстояние в");
            System.out.println(distanceBus + "км c " + bus1.passengers);
            System.out.println(" пассажирами.");
        }
    }







