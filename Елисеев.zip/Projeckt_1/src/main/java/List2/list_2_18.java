package List2;

public class list_2_18 {
    public static void main(String[] args) {
        char ch = 'Я';
        do {
            System.out.println(ch);
            ch--;
        } while (ch >= 'А');
    } // main(String[])
} // AlphabetDoWhileDemo class



