package List2;

public class list_2_14 {
    public static void main(String[] args) {

        long l = 10;
        double d = 1;
        l = (long) d;
    } // main(String[])
} // ExplicitCast class

